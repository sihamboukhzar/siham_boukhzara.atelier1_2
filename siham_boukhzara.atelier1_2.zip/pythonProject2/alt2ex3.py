# compter l'occurrence de chaque élément et créer un dictionnaire pour montrer le nombre de chaque élément
s = [11, 45, 8, 11, 23, 45, 23, 45, 89]
n=0
l = {}  #definie un set vide
for e in s : # boucle pour calculer le nombre d'elemets de la lists
    n = n+1
print("n=",n)
def frequence() :   #definition  d'une fonction
    for e in s :
        nbr = 0
        for i in range(0, n):        # boucle pour traiter la compatibilité
               if e == s[i] :
                 nbr = nbr + 1
        l={e:nbr}
        print(l)             # l'affichage de la liste
    return 0
frequence() #l'appele de la fonction