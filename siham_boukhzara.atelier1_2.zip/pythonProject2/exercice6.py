# tri par sélection
def trisection(T , n ) :    # la declaration d'une fonction :
    for i in range (n-1):
        p = i
        for j in range (i+1,n):
            if T[j]<T[p]:
                p=j
        T[i],T[p]=T[p],T[i]
# tri a bull
def tribull (l) :             # la declaration d'une fonction :
    n = len(l)           # une fonction qu'il donne la langeur de notre tableau
    for i in range(n-1, 0, -1):
        for j in range(i):
            if l[i] > l[i+1]:
              l [i], l[i+1] = l[i+1], l[i]
# tri par insertion
def tri_insertion (T,n):      # la declaration d'une fonction :
    for i in range(n):
        j = j-1
        while( j >= 0 and T[j] > T[j+1] ) :
            T[i], T[j+1] = T[j+1], T[j]
            j = j-1
