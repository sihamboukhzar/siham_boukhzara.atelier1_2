#Deviser la liste en 3 morceaux égaux et inverser chaque morceau
l=[0,11, 45, 8, 23, 14, 12, 78, 45, 89] #  la définition d'une  liste
l1=print(l[3:0:-1]) #Deviser la liste et inverser le morceau par la lecture inverse
l2=print(l[6:3:-1])
l3=print(l[9:6:-1])