# un programme pour créer une troisième liste l3 en choisissant un élément d'indice impair dans la liste l1 et des éléments d'indice pair dans la liste l2
l1 = [3, 6, 9, 12, 15, 18, 21] # déclaration et remplissage  de la liste 1
l2 = [4 , 8, 12, 16, 20, 24, 28] #déclaration  et remplissage de la liste 2
l = []                   # déclaration d'une liste vide
for element in l1:      # boucle que lit  les élémets de la list
    if element % 2 == 1: # tester si l'élémet est impaire
        l.append(element) # l'ajoute des élémets impaire de la première liste dans la liste vide
for elmen in l2 :
    if elmen % 2 == 0 : # tester si l'élémet est paire
        l.append(elmen) # l'ajoute des élémets paire de la deuxème liste  dans la liste vide
print(l)        # l'affichage de la liste après l'ajout des élémets




