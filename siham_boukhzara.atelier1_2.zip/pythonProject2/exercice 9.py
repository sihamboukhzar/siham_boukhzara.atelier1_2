#herche un élément dans une matrice puis renvoi sa position
my_list = [1, 4, 6, 3, 10, 6, 19, 11 ,10 ,10 ,6] #déclaration et remplissage de la list
n=len(my_list) # la langueur de notre liste
def position(x):  # la déclaration de  la fonction position
        nbr = 0 #initiation du compteur
        m = 0 #initiation de la position
        for i in range(n):
                if x == my_list[i]: # validation de la compatibilité
                        nbr = nbr + 1  # compteur de la position
                        print("la position :", nbr, " de ", x, "est : ", m)
                        m = m+1       #incrémentation
                else :
                        m = m + 1  #incrémentation  pour passer à la position suivante
        return m
x = int (input("choisir un nombre : ")) #demande à l'utilisateur d'entrer une valeur dans notre liste
position(x)         #l'appele de la fonction