l = [47, 64, 69, 37, 76, 83, 95, 97]
s = {'Yassine':47, 'Imane':69, 'Mohammed':76, 'Abir':97}
