# imprimer la série Fibonacci en utilisant la récursivité.
def fibonacci(n): # la declaration d'une fonction : calculer la somme de les deux nombre précident
    if(n<=0):    # la dernier faleur qu'il peut prendre n c'est 0 alors dans ce cas va retourner 1
        return 1
    else :
        return (fibonacci(n-1)+fibonacci(n-2)) # la somme de deux nombre récurrant
n = int(input("entrer la valeur de n :"))  #demande à l'utilisateur d'entrer une valeur
print("la serie de finonacci est : ")
for i in range(n):
  print(fibonacci(i))   # boucle qu'il va affichier  la serie de fibonacci