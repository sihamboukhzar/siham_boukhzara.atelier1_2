#un programme pour trouver la somme  des séries
def factoriel(x):  # la declaration d'une fonction : une fonction récursive pour calculer le  factoriel
  if x==1 :             #c'est la dernier faleur qu'il peut prendre x  : facrtoriel(0)=1 si pour cela on a mettre qu'il va return 1
    return 1
  else :
    return x*factoriel(x-1)    # le dernier élément fois le factoriel d'élément précident
s=0
for i in range (1,6):  #une boucle commence de 1 jusqu'à 6 pour faire la somme
    s=s+(factoriel(i)/i)           # appler notre fonction pour calculer le  factoriel
print("la somme est ",s )    # l'affichage de notre resultat






