#l'intersection (commune) de deux Sets et supprimez ces éléments du premier Set
set_1 = {23, 42, 65, 57, 78, 83, 29}
set_2 = {57, 83, 29, 67, 73, 43, 48}
print(set_1.intersection(set_2)) # l'affichage de l'intersection de set_1 et set_2
print(set_1.difference(set_2)) # l'affichage de la difference de de set_1 et set_2
