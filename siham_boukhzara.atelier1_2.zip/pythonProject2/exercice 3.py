# calculer la somme des nombres de 1 à n
def somme(n): # la declaration d'une fonction : qu'il va calculer la somme de 1 jusqu'à un nombre donner par l'utilisateur
    if n==0:
       return 0
    else :
       return n+ somme(n-1)   # le dernier élément + la somme d'élément précident
n=int(input("entrer la valeur de n :"))  # demander à l'utilisateur de donner un nombre entier
print ("la somme est :",somme(n))  # l'affichage de la somme