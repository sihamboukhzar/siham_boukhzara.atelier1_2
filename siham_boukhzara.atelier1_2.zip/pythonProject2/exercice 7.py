#inverse les lettres d’une chaîne de caractères
def inverse(s): # déclaration de la fonction
    inv = ""    # initiation
    for x in s:    # boucle pour traiter  les lettres de notre chaîne saisie
        inv = x + inv # permuataion
    return inv        # retourner la valeur
s = input("entrer le mot : ")  # saisir une chaine de caractère
print("l'inverse est : ", inverse(s)) # l'affichage du mot incersé





