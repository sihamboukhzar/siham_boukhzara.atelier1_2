#convertir le nombre décimal en nombre binaire
def cov(x) :               # fonction recurcive pour  convertir le nombre décimal en nombre binaire
    if x==0 :
        return 0
    else :
        return (x%2)+(10*cov(x//2))   # retourner le nombre en binaire en utilisant dévision entières successives jusqu'à ce que quotient devienne null
x=int(input("entrer la valeur en décimal :  "))             # demande à l'utilisateur d'entrer une valeur
print("la somme est ", cov(x))                      # l'affichage de notre fonction