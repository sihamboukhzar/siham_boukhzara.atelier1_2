 #compter les chiffres d'un nombre donné en utilisant la récursivité.
def compter_chiffres (n): # declaration de la fonction
    nbr=0                # initiation de compteur
    for i in range (n): # boucle pour répéter le traitement n fois
       if n != 0:
        n = n // 10 # cette opperation donne la division et le résultat est un entier natural
        nbr = nbr + 1 # compteur
    return nbr        # retourne l
n = int(input("vueilliez saisie la valreur de n : "))  # demande à l'utilisateur d'entrer une valeur
print("le nombre des chifres est : ", compter_chiffres(n))  # l'affichage de notre foncton