# la fréquence d’un caractère dans une chaîne:
s = input("entrer le mot : ") #saisir la chaîne  de caractère
n = len(s)                # fonction donne la langeur de notre chaîne
def count(x) :            # déclaration de la fonction qu'il va compter la fréquence des  caractères
    nbr = 0                 # initiation de compteur
    for i in range(0, n):  # boucle pour répéter le traitement pour chaque  caractères
        if x == s[i]:      # on va tester si l'élément a choisi par l'utilisateur est compatible avec les caractères de notre chaîne
            nbr = nbr + 1  # compteur de la fréquence dans la qu'il les éléments sont compatible
    return nbr
x=input("choisir le caractere : ")
print("la frequence est : ", count(x)) # l'affichage du résultat